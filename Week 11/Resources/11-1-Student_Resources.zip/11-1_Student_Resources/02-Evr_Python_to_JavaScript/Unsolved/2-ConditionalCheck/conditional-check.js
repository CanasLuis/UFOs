// Checks if one value is equal to another

// Checks if one value is NOT equal to another

// Checks if one value is less than another

// Checks if one value is greater than another

// Checks if a value is less than or equal to another

// Checks for two conditions to be met using &&

// Checks if either of two conditions is met using ||

// Nested if statements
